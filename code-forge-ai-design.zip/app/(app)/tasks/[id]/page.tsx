import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeftIcon, GitBranchIcon, SparklesIcon } from "lucide-react"

import { getTask, tasks } from "@/lib/data/tasks"
import { getProject, projects } from "@/lib/data/projects"

import { PageHeader } from "@/components/shared/page-header"
import { PriorityBadge, SeverityBadge, StatusBadge } from "@/components/shared/status-badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export function generateStaticParams() {
  return tasks.map((task) => ({ id: task.id }))
}

export default async function TaskDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const task = getTask(id)
  if (!task) notFound()

  const project = projects.find((p) => p.name === task.repository)

  return (
    <div className="flex flex-col gap-6">
      <Button variant="ghost" size="sm" className="w-fit" asChild>
        <Link href="/tasks">
          <ArrowLeftIcon aria-hidden="true" />
          Back to Tasks
        </Link>
      </Button>

      <PageHeader
        title={task.title}
        description={task.id}
        actions={
          <div className="flex items-center gap-2">
            <PriorityBadge priority={task.priority} />
            <StatusBadge status={task.status} />
          </div>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Description</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <p className="text-sm text-muted-foreground">
              {task.description ?? "No additional description was provided for this task."}
            </p>
            {task.severity ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Severity</span>
                <SeverityBadge severity={task.severity} />
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Details</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Assigned Agent</span>
              <Link href="/agents" className="flex items-center gap-1.5 font-medium text-foreground hover:underline">
                <SparklesIcon className="size-3.5" aria-hidden="true" />
                {task.agent}
              </Link>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Repository</span>
              {project ? (
                <Link
                  href={`/projects/${project.id}`}
                  className="flex items-center gap-1.5 font-medium text-foreground hover:underline"
                >
                  <GitBranchIcon className="size-3.5" aria-hidden="true" />
                  {task.repository}
                </Link>
              ) : (
                <span className="font-medium text-foreground">{task.repository}</span>
              )}
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Created</span>
              <span className="font-medium text-foreground">{task.created}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Last Updated</span>
              <span className="font-medium text-foreground">{task.updated}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
