import Link from "next/link"

import { tasks } from "@/lib/data/tasks"

import { PageHeader } from "@/components/shared/page-header"
import { PriorityBadge, StatusBadge } from "@/components/shared/status-badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function TasksPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Tasks"
        description="Every task assigned to an agent across all projects."
        actions={<Button>New Task</Button>}
      />

      <div className="overflow-hidden rounded-xl border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Task</TableHead>
              <TableHead>Repository</TableHead>
              <TableHead>Agent</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Updated</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tasks.map((task) => (
              <TableRow key={task.id} className="cursor-pointer">
                <TableCell className="max-w-xs">
                  <Link href={`/tasks/${task.id}`} className="flex flex-col gap-0.5">
                    <span className="font-medium text-foreground">{task.title}</span>
                    <span className="text-xs text-muted-foreground">{task.id}</span>
                  </Link>
                </TableCell>
                <TableCell className="text-muted-foreground">{task.repository}</TableCell>
                <TableCell className="text-muted-foreground">{task.agent}</TableCell>
                <TableCell>
                  <PriorityBadge priority={task.priority} />
                </TableCell>
                <TableCell>
                  <StatusBadge status={task.status} />
                </TableCell>
                <TableCell className="text-right text-muted-foreground">{task.updated}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
