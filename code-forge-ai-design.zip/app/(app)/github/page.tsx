import { CheckIcon, CircleIcon, GitBranchIcon, GitCommitHorizontalIcon, GitPullRequestIcon, StarIcon } from "lucide-react"

import { approvalWorkflow, commits, issues, pullRequests, repositories } from "@/lib/data/github"

import { PageHeader } from "@/components/shared/page-header"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export default function GithubPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="GitHub Integration"
        description="Repository activity and the human-in-the-loop approval workflow agents follow before merging."
      />

      <Card>
        <CardHeader>
          <CardTitle>Approval Workflow</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-2">
            {approvalWorkflow.map((step, i) => (
              <div key={step} className="flex items-center gap-2">
                <span className="rounded-md border border-border bg-muted px-2.5 py-1 text-xs font-medium text-foreground">
                  {step}
                </span>
                {i < approvalWorkflow.length - 1 ? (
                  <span className="text-muted-foreground" aria-hidden="true">
                    &rarr;
                  </span>
                ) : null}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Repositories</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          {repositories.map((repo) => (
            <div
              key={repo.name}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-4"
            >
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "flex size-2 shrink-0 rounded-full",
                    repo.ci === "passing" ? "bg-success" : "bg-destructive",
                  )}
                  aria-hidden="true"
                />
                <div className="flex flex-col gap-0.5">
                  <span className="font-mono text-sm font-medium text-foreground">{repo.name}</span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <GitBranchIcon className="size-3" aria-hidden="true" />
                    {repo.branch}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <StarIcon className="size-3" aria-hidden="true" />
                  {repo.stars}
                </span>
                <span>{repo.openIssues} issues</span>
                <span>{repo.openPRs} PRs</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Open Issues</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {issues.map((issue) => (
              <div key={issue.id} className="flex flex-col gap-1.5 rounded-lg border border-border p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{issue.id}</span>
                  <Badge variant="outline" className="capitalize">
                    {issue.status.replace("-", " ")}
                  </Badge>
                </div>
                <span className="text-sm font-medium text-foreground">{issue.title}</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-muted-foreground">{issue.repo}</span>
                  {issue.labels.map((label) => (
                    <Badge key={label} variant="secondary" className="text-[10px]">
                      {label}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pull Requests</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {pullRequests.map((pr) => (
              <div key={pr.id} className="flex flex-col gap-1.5 rounded-lg border border-border p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 font-mono text-xs text-muted-foreground">
                    <GitPullRequestIcon className="size-3" aria-hidden="true" />
                    {pr.id}
                  </span>
                  <Badge variant="outline" className="capitalize">
                    {pr.status}
                  </Badge>
                </div>
                <span className="text-sm font-medium text-foreground">{pr.title}</span>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {pr.repo} &middot; {pr.author}
                  </span>
                  <span
                    className={cn(
                      "flex items-center gap-1",
                      pr.checks === "passing" ? "text-success" : "text-warning",
                    )}
                  >
                    {pr.checks === "passing" ? (
                      <CheckIcon className="size-3" aria-hidden="true" />
                    ) : (
                      <CircleIcon className="size-3" aria-hidden="true" />
                    )}
                    {pr.checks}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Commits</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          {commits.map((commit) => (
            <div key={commit.sha} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
              <div className="flex items-center gap-3">
                <GitCommitHorizontalIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm text-foreground">{commit.message}</span>
                  <span className="text-xs text-muted-foreground">
                    {commit.repo} &middot; {commit.author}
                  </span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-0.5 text-right">
                <span className="font-mono text-xs text-muted-foreground">{commit.sha}</span>
                <span className="text-xs text-muted-foreground">{commit.time}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
