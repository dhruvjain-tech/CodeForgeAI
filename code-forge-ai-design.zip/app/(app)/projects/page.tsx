import Link from "next/link"
import { ClockIcon, ListChecksIcon } from "lucide-react"

import { projects } from "@/lib/data/projects"

import { HealthBar } from "@/components/shared/health-bar"
import { PageHeader } from "@/components/shared/page-header"
import { StatusBadge } from "@/components/shared/status-badge"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ProjectsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Projects" description="All repositories under active agent supervision." />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {projects.map((project) => (
          <Link key={project.id} href={`/projects/${project.id}`}>
            <Card className="h-full transition-colors hover:border-primary/40">
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div className="flex flex-col gap-1">
                  <CardTitle>{project.name}</CardTitle>
                  <span className="text-xs text-muted-foreground">{project.repository}</span>
                </div>
                <StatusBadge status={project.status} />
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <p className="text-sm text-muted-foreground">{project.description}</p>
                <div className="flex flex-wrap gap-1.5">
                  {project.stack.map((tech) => (
                    <Badge key={tech} variant="secondary">
                      {tech}
                    </Badge>
                  ))}
                </div>
                <HealthBar label="Code Health" value={project.codeHealth} />
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <ListChecksIcon className="size-3.5" aria-hidden="true" />
                    {project.activeTasks} active tasks
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ClockIcon className="size-3.5" aria-hidden="true" />
                    {project.lastActivity}
                  </span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
