import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeftIcon } from "lucide-react"

import { getProject, projects } from "@/lib/data/projects"
import { tasks } from "@/lib/data/tasks"

import { HealthBar } from "@/components/shared/health-bar"
import { PageHeader } from "@/components/shared/page-header"
import { PriorityBadge, StatusBadge } from "@/components/shared/status-badge"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { ListChecksIcon } from "lucide-react"

export function generateStaticParams() {
  return projects.map((project) => ({ id: project.id }))
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const project = getProject(id)
  if (!project) notFound()

  const projectTasks = tasks.filter((t) => t.repository === project.name)

  return (
    <div className="flex flex-col gap-6">
      <Button variant="ghost" size="sm" className="w-fit" asChild>
        <Link href="/projects">
          <ArrowLeftIcon aria-hidden="true" />
          Back to Projects
        </Link>
      </Button>

      <PageHeader
        title={project.name}
        description={project.repository}
        actions={<StatusBadge status={project.status} />}
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Overview</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <p className="text-sm text-muted-foreground">{project.description}</p>
            <div className="flex flex-wrap gap-1.5">
              {project.stack.map((tech) => (
                <Badge key={tech} variant="secondary">
                  {tech}
                </Badge>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2 sm:grid-cols-3">
              <div className="flex flex-col gap-1">
                <span className="text-xs text-muted-foreground">Active Tasks</span>
                <span className="text-xl font-semibold text-foreground">{project.activeTasks}</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-xs text-muted-foreground">Last Activity</span>
                <span className="text-xl font-semibold text-foreground">{project.lastActivity}</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-xs text-muted-foreground">Code Health</span>
                <span className="text-xl font-semibold text-foreground">{project.codeHealth}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Code Health</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <HealthBar label="Overall" value={project.codeHealth} />
            <Button variant="outline" size="sm" asChild className="w-fit">
              <Link href="/code-health">View full report</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tasks</CardTitle>
        </CardHeader>
        <CardContent>
          {projectTasks.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <ListChecksIcon aria-hidden="true" />
                </EmptyMedia>
                <EmptyTitle>No tasks yet</EmptyTitle>
                <EmptyDescription>This project has no active or historical tasks.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="flex flex-col gap-1">
              {projectTasks.map((task) => (
                <Link
                  key={task.id}
                  href={`/tasks/${task.id}`}
                  className="flex items-center justify-between gap-4 rounded-lg px-3 py-2.5 transition-colors hover:bg-muted"
                >
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-medium text-foreground">{task.title}</span>
                    <span className="text-xs text-muted-foreground">{task.id}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <PriorityBadge priority={task.priority} className="hidden sm:inline-flex" />
                    <StatusBadge status={task.status} />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
